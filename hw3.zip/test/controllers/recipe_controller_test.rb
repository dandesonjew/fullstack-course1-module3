require 'test_helper'

class RecipeControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
